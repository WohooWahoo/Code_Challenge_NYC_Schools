//
//  CustomNavigationController.swift
//  NYC-Schools SAT scores
//
//  Created by rtb on 1/12/20.
//  Copyright © 2020 rtb. All rights reserved.
//

import UIKit

class CustomNavigationController: UINavigationController {
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
