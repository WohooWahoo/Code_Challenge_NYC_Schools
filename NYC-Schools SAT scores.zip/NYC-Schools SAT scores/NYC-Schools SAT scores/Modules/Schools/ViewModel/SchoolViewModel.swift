//
//  SchoolViewModel.swift
//  NYC-Schools SAT scores
//
//  Created by rtb on 1/12/20.
//  Copyright © 2020 rtb. All rights reserved.
//

import Foundation

struct SchoolViewModel {
    
    let name: String
    let city: String
    let dbn: String
    
    init(school: School) {
        self.name = school.school_name
        self.city = school.city
        self.dbn = school.dbn
    }
    
}
