//
//  School.swift
//  NYC-Schools SAT scores
//
//  Created by rtb on 1/12/20.
//  Copyright © 2020 rtb. All rights reserved.
//

import Foundation

struct School: Decodable {
    
    var school_name: String
    var city: String
    var dbn: String
    
}
