//
//  Detail.swift
//  NYC-Schools SAT scores
//
//  Created by rtb on 1/12/20.
//  Copyright © 2020 rtb. All rights reserved.
//

import Foundation

struct Detail: Decodable {
    
    var sat_critical_reading_avg_score: String
    var sat_math_avg_score: String
    var sat_writing_avg_score: String
    var num_of_sat_test_takers: String
    var dbn: String
    
}
